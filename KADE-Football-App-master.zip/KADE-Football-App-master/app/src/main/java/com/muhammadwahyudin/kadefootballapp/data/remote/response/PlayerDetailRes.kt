package com.muhammadwahyudin.kadefootballapp.data.remote.response

import com.muhammadwahyudin.kadefootballapp.data.model.Player

data class PlayerDetailRes(
    val players: List<Player>
)