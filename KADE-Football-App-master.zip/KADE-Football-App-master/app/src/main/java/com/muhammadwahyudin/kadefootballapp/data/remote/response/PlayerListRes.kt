package com.muhammadwahyudin.kadefootballapp.data.remote.response

import com.muhammadwahyudin.kadefootballapp.data.model.Player

data class PlayerListRes(
    val player: List<Player>
)